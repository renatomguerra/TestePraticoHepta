﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hepta.PraticalEvaluation.Domain
{
    public class BinaryNumber: BaseEntity<int>
    {
        public string Value { get; set; }
    }
}
